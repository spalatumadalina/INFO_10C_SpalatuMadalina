n=8
print(n," metri=",n*100," centimetri ")
print(n," kg=",n*1000," miligrame ")
print(n," ani=",n*12," luni ")
print(n," luni=",n*4," saptamani ")
print(n," ani=",n*365,"zile")