a=4 
print("Aria=",a**2)
print("Perimetrul=",a*12)
print("Volumul=",a**3)
